import { createFileRoute } from "@tanstack/react-router";
import { ContactPage } from "@/components/royal-site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Royal Cricket Ground" },
      { name: "description", content: "Call, WhatsApp, email, or find Royal Cricket Ground on Google Maps for bookings and cricket slot enquiries." },
      { property: "og:title", content: "Contact Royal Cricket Ground" },
      { property: "og:description", content: "Reach Royal Cricket Ground quickly with map directions, contact details, and direct booking actions." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});
