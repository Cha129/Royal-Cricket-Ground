import { createFileRoute } from "@tanstack/react-router";
import { PricingPage } from "@/components/royal-site";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Royal Cricket Ground" },
      { name: "description", content: "Weekday and weekend cricket slot pricing at Royal Cricket Ground including the Whole Day Package with live streaming, CricHeroes, leather balls, medals, and Free WiFi." },
      { property: "og:title", content: "Pricing — Royal Cricket Ground" },
      { property: "og:description", content: "Transparent weekday and weekend cricket turf pricing with a premium Whole Day Package." },
      { property: "og:url", content: "/pricing" },
    ],
    links: [{ rel: "canonical", href: "/pricing" }],
  }),
  component: PricingPage,
});