import { createFileRoute } from "@tanstack/react-router";
import { BookSlotPage } from "@/components/royal-site";

export const Route = createFileRoute("/book-slot")({
  head: () => ({
    meta: [
      { title: "Book a Cricket Slot — Royal Cricket Ground" },
      { name: "description", content: "Check cricket slot timings, pricing, availability, and send a quick booking request to Royal Cricket Ground." },
      { property: "og:title", content: "Book a Cricket Slot — Royal Cricket Ground" },
      { property: "og:description", content: "Reserve morning, afternoon, or night cricket slots with quick WhatsApp booking." },
      { property: "og:url", content: "/book-slot" },
    ],
    links: [{ rel: "canonical", href: "/book-slot" }],
  }),
  component: BookSlotPage,
});