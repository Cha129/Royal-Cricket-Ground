import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/royal-site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Royal Cricket Ground — Book Cricket Slots" },
      { name: "description", content: "Book premium cricket turf slots at Royal Cricket Ground with timings, facilities, tournaments, gallery, and direct WhatsApp contact." },
      { property: "og:title", content: "Royal Cricket Ground — Book Cricket Slots" },
      { property: "og:description", content: "Premium cricket turf booking platform with facilities, tournaments, and quick reservations in Moinabad." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});