import { createFileRoute } from "@tanstack/react-router";
import { FacilitiesPage } from "@/components/royal-site";

export const Route = createFileRoute("/facilities")({
  head: () => ({
    meta: [
      { title: "Facilities — Royal Cricket Ground" },
      { name: "description", content: "Explore parking, practice nets, changing rooms, café access, washrooms, and spectator facilities at Royal Cricket Ground." },
      { property: "og:title", content: "Facilities — Royal Cricket Ground" },
      { property: "og:description", content: "See the premium on-ground facilities available for players, teams, and spectators." },
      { property: "og:url", content: "/facilities" },
    ],
    links: [{ rel: "canonical", href: "/facilities" }],
  }),
  component: FacilitiesPage,
});