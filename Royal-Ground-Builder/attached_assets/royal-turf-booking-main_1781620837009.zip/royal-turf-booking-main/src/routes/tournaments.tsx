import { createFileRoute } from "@tanstack/react-router";
import { TournamentsPage } from "@/components/royal-site";

export const Route = createFileRoute("/tournaments")({
  head: () => ({
    meta: [
      { title: "Tournaments — Royal Cricket Ground" },
      { name: "description", content: "View upcoming Royal Cricket Ground tournaments, prize pools, registrations, and recent competition results." },
      { property: "og:title", content: "Tournaments — Royal Cricket Ground" },
      { property: "og:description", content: "Register teams for upcoming competitions and explore past tournament highlights." },
      { property: "og:url", content: "/tournaments" },
    ],
    links: [{ rel: "canonical", href: "/tournaments" }],
  }),
  component: TournamentsPage,
});
