import { createFileRoute } from "@tanstack/react-router";
import { GalleryPage } from "@/components/royal-site";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Royal Cricket Ground" },
      { name: "description", content: "Browse Royal Cricket Ground photos featuring turf views, match moments, pavilion spaces, and event highlights." },
      { property: "og:title", content: "Gallery — Royal Cricket Ground" },
      { property: "og:description", content: "Real photos from Royal Cricket Ground across matches, pavilion views, and event moments." },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});
