import { createFileRoute } from "@tanstack/react-router";
import { AboutPage } from "@/components/royal-site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Royal Cricket Ground" },
      { name: "description", content: "Learn about Royal Cricket Ground, its mission, turf experience, facilities, and why players choose it for premium cricket in Moinabad." },
      { property: "og:title", content: "About Royal Cricket Ground" },
      { property: "og:description", content: "Explore the story, turf details, and premium facilities behind Royal Cricket Ground." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});