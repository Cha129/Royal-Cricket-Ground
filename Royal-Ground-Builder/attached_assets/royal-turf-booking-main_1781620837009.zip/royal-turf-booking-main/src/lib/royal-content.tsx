import type { LucideIcon } from "lucide-react";
import {
  CalendarDays,
  Camera,
  CircleDollarSign,
  Coffee,
  Crown,
  Droplets,
  Flag,
  Lamp,
  ListChecks,
  MapPinned,
  Medal,
  Phone,
  ShieldCheck,
  Store,
  Trophy,
  Users,
  UtensilsCrossed,
  Warehouse,
  Waves,
  Wifi,
} from "lucide-react";

import groundSunsetWide from "@/assets/royal-ground-sunset-wide.png.asset.json";
import groundSunsetAngle from "@/assets/royal-ground-sunset-angle.png.asset.json";
import pavilionPhoto from "@/assets/royal-pavilion.png.asset.json";
import loungeViewPhoto from "@/assets/royal-view-from-lounge.png.asset.json";
import inaugurationPhoto from "@/assets/royal-inauguration.png.asset.json";
import groundDayWide from "@/assets/royal-ground-daywide.png.asset.json";
import storefrontPhoto from "@/assets/royal-storefront.png.asset.json";
import logoAsset from "@/assets/royal-logo.png.asset.json";
import ownerPortrait from "@/assets/lal-ahmed-portrait.png.asset.json";
import ownerAward from "@/assets/lal-ahmed-award.png.asset.json";
import ownerMedal from "@/assets/lal-ahmed-medal.png.asset.json";
import ownerTrophy from "@/assets/lal-ahmed-trophy.png.asset.json";

export const site = {
  name: "Royal Cricket Ground",
  shortName: "RCG",
  phone: "+91 90004 00411",
  whatsappNumber: "919550810878",
  whatsappDisplay: "+91 95508 10878",
  email: "hello@royalcricketground.com",
  instagram: "https://www.instagram.com/royalcricketground/",
  facebook: "#",
  youtube: "#",
  address: "Road near Mango Villa Farm House, Peddamangalaram, Moinabad, Telangana 501504",
  mapEmbed:
    "https://www.google.com/maps?q=road%20near%20mango%20villa%20farm%20house%2C%20Peddamangalaram%2C%20Moinabad%2C%20Telangana%20501504&z=15&output=embed",
  mapLink:
    "https://www.google.com/maps?daddr=road,+near+mango+villa+farm+house,+Peddamangalaram,+Moinabad,+Telangana+501504",
  openingHours: [
    "Morning slots · 6:00 AM – 10:00 AM",
    "Afternoon slots · 12:00 PM – 5:00 PM",
    "Evening & night slots · 6:00 PM – 12:00 AM",
  ],
};

export const navItems = [
  { label: "Home", to: "/" as const },
  { label: "About", to: "/about" as const },
  { label: "Book a Slot", to: "/book-slot" as const },
  { label: "Pricing", to: "/pricing" as const },
  { label: "Facilities", to: "/facilities" as const },
  { label: "Gallery", to: "/gallery" as const },
  { label: "Tournaments", to: "/tournaments" as const },
  { label: "Contact", to: "/contact" as const },
];

export const heroStats = [
  { label: "Ground type", value: "Professional turf" },
  { label: "Daily play windows", value: "3 slot bands" },
  { label: "Tournament-ready setup", value: "Team events" },
];

export const highlights: Array<{ title: string; description: string; icon: LucideIcon }> = [
  {
    title: "Premium Turf",
    description: "Well-maintained cricket surface built for practice sessions, friendlies, and serious match days.",
    icon: Crown,
  },
  {
    title: "Night Matches",
    description: "Play high-energy evening cricket with a stadium-style atmosphere.",
    icon: Lamp,
  },
  {
    title: "Online Slot Booking",
    description: "Explore timings, pricing, and contact options that make reserving your game fast and simple.",
    icon: CalendarDays,
  },
  {
    title: "Tournament Hosting",
    description: "Run club events, local competitions, and knockout weekends with organized ground support.",
    icon: Trophy,
  },
  {
    title: "Practice Nets",
    description: "Dedicated training-friendly spaces for batting reps, bowling rhythm, and focused prep.",
    icon: ShieldCheck,
  },
  {
    title: "Spacious Parking",
    description: "Easy arrival and exit with practical parking access for bikes, cars, teams, and guests.",
    icon: Warehouse,
  },
  {
    title: "Changing Rooms",
    description: "Clean, secure player areas that support pre-match prep and post-game cool-down routines.",
    icon: Users,
  },
  {
    title: "Refreshments & Café",
    description: "Snacks, hydration, and essentials close to the ground so players stay match-ready.",
    icon: Coffee,
  },
];

export const aboutCards = [
  {
    title: "Built for local cricket culture",
    description:
      "Royal Cricket Ground is designed as a premium playing space where regular players, clubs, and communities can compete in a professional environment.",
  },
  {
    title: "A premium match-day experience",
    description:
      "From turf quality and lighting to viewing angles and player amenities, every detail supports more enjoyable cricket for every age group.",
  },
  {
    title: "A growing community hub",
    description:
      "It’s more than a booking venue — it’s a destination for practice sessions, tournaments, celebrations, and weekend cricket energy.",
  },
];

export const groundDetails: Array<{ label: string; value: string; icon: LucideIcon }> = [
  { label: "Ground Type", value: "Professional cricket turf venue", icon: Flag },
  { label: "Turf Type", value: "Premium maintained turf surface", icon: Waves },
  { label: "Pitch Type", value: "Match-ready pitch with training support", icon: ListChecks },
  { label: "Match Formats", value: "Practice, box cricket, and organized fixtures", icon: Medal },
  { label: "Seating Capacity", value: "Player and spectator viewing areas", icon: Users },
  { label: "Night Matches", value: "Available for evening and night play", icon: Lamp },
];

export const facilitiesOverview: Array<{ title: string; description: string; icon: LucideIcon }> = [
  
  { title: "Parking", description: "Spacious parking for bikes and cars.", icon: Warehouse },
  { title: "Practice Nets", description: "Dedicated cricket practice space.", icon: ShieldCheck },
  { title: "Dressing Rooms", description: "Comfortable player prep areas.", icon: Users },
  { title: "Washrooms", description: "Clean and maintained utility spaces.", icon: Droplets },
  { title: "Drinking Water", description: "Hydration support for long sessions.", icon: Waves },
  { title: "Café & Snacks", description: "Refreshments available near the ground.", icon: UtensilsCrossed },
  { title: "Spectator Area", description: "Relaxed viewing zones for supporters and guests.", icon: Camera },
  { title: "Free WiFi", description: "Fast internet access for players and visitors — great for live streaming and score tracking.", icon: Wifi },
];

export const slotBands = [
  {
    label: "Morning",
    time: "6:00 AM – 10:00 AM",
    status: "Available",
    note: "Best for early practice and fresh turf sessions.",
  },
  {
    label: "Afternoon",
    time: "12:00 PM – 5:00 PM",
    status: "Limited slots",
    note: "Great for team nets, coaching, and shorter fixtures.",
  },
  {
    label: "Evening / Night",
    time: "6:00 PM – 12:00 AM",
    status: "Booked fast",
    note: "Prime-time cricket under lights with peak energy.",
  },
];

export const pricing = [
  {
    title: "Weekday Pricing",
    price: "₹1,500 / hour",
    points: ["Ideal for practice sessions", "Flexible daytime slots", "WhatsApp quick confirmation"],
  },
  {
    title: "Weekend Pricing",
    price: "₹2,000 / hour",
    points: ["Peak demand timing", "Best for team play", "Priority support for repeat groups"],
  },
  {
    title: "Tournament Pricing",
    price: "Custom package",
    points: ["Multi-slot planning", "Ground support coordination", "Night-match add-ons available"],
  },
];

export const galleryFilters = ["All", "Ground", "Matches", "Pavilion", "Events"] as const;

export const galleryItems = [
  { title: "Sunset match atmosphere", category: "Matches", image: groundSunsetWide.url },
  { title: "Golden-hour boundary view", category: "Ground", image: groundSunsetAngle.url },
  { title: "Pavilion and player zone", category: "Pavilion", image: pavilionPhoto.url },
  { title: "Lounge view toward the pitch", category: "Pavilion", image: loungeViewPhoto.url },
  { title: "Ground inauguration moment", category: "Events", image: inaugurationPhoto.url },
  { title: "Wide ground daylight view", category: "Ground", image: groundDayWide.url },
  { title: "Royal store and reception", category: "Pavilion", image: storefrontPhoto.url },
];

export const tournaments = [
  {
    name: "Royal Weekend League",
    date: "July 20, 2026",
    prize: "₹25,000",
    fee: "₹3,500",
    capacity: "8 teams",
  },
  {
    name: "Night Warriors Cup",
    date: "August 2, 2026",
    prize: "₹40,000",
    fee: "₹5,000",
    capacity: "12 teams",
  },
  {
    name: "Corporate Turf Challenge",
    date: "August 18, 2026",
    prize: "Trophies + awards",
    fee: "Custom",
    capacity: "6 teams",
  },
];

export const tournamentResults = [
  {
    title: "RCG Launch Trophy",
    winner: "Royal Strikers",
    runnerUp: "Boundary Kings",
    summary: "An energetic opening event with close finishes and strong local crowd support.",
  },
  {
    title: "Evening Light Series",
    winner: "Powerplay XI",
    runnerUp: "Pitch Invaders",
    summary: "Fast-paced night fixtures showcased the ground’s premium playing atmosphere.",
  },
];

export const testimonials = [
  {
    quote:
      "One of the most polished local cricket venues we’ve played on — excellent lighting and a very smooth booking experience.",
    name: "Aditya R.",
    role: "Weekend team captain",
  },
  {
    quote:
      "The ground feels premium, especially for evening matches. Parking and player facilities make it easy for full squads.",
    name: "Sai Teja",
    role: "Tournament organizer",
  },
  {
    quote:
      "We booked quickly on WhatsApp and had all our slot details confirmed fast. Perfect for repeat practice sessions.",
    name: "Vamsi K.",
    role: "Club player",
  },
];

export const faqs = [
  {
    question: "How do I book a slot at Royal Cricket Ground?",
    answer:
      "Choose your preferred timing, fill in your basic details, and use the quick WhatsApp or call action to confirm your slot fast.",
  },
  {
    question: "Are night matches available?",
    answer:
      "Yes. Royal Cricket Ground supports evening and late-night play, subject to slot availability.",
  },
  {
    question: "Can we register a full team for tournaments?",
    answer:
      "Yes. The tournaments page includes a team registration form for upcoming competitions and event announcements.",
  },
  {
    question: "What facilities are available on-site?",
    answer:
      "The venue includes parking, changing areas, refreshment access, spectator spaces, practice-friendly infrastructure, and maintained utilities.",
  },
];

export const quickLinks = [
  { label: "Book a slot", to: "/book-slot" as const },
  { label: "Pricing", to: "/pricing" as const },
  { label: "View facilities", to: "/facilities" as const },
  { label: "See gallery", to: "/gallery" as const },
  { label: "Upcoming tournaments", to: "/tournaments" as const },
  { label: "Contact us", to: "/contact" as const },
];

export const socialLinks = [
  { label: "Instagram", href: site.instagram },
  { label: "Facebook", href: site.facebook },
  { label: "YouTube", href: site.youtube },
  { label: "WhatsApp", href: `https://wa.me/${site.whatsappNumber}` },
];

export const images = {
  logo: logoAsset.url,
  hero: groundSunsetWide.url,
  sunset: groundSunsetAngle.url,
  pavilion: pavilionPhoto.url,
  lounge: loungeViewPhoto.url,
  inauguration: inaugurationPhoto.url,
  wide: groundDayWide.url,
  store: storefrontPhoto.url,
};

export const owner = {
  name: "Lal Ahmed",
  role: "Founder & Owner · Royal Cricket Ground",
  tagline: "Star bowler, all-round player, and on-field fighter behind countless match-day wins.",
  bio: "Lal Ahmed is the heart of Royal Cricket Ground — the founder who built this venue from the ground up and one of the most respected players in the local cricket circuit. Known for his sharp bowling, fearless batting, and never-back-down attitude, he has led teams to victory in countless matches and tournaments.",
  achievements: [
    "Best bowler across multiple local tournaments",
    "All-rounder with match-winning performances",
    "On-field fighter known for clutch overs and finishes",
    "Mentor and host to teams playing at RCG",
  ],
  portrait: ownerPortrait.url,
  gallery: [
    { url: ownerTrophy.url, caption: "Lifting silverware after a tournament final" },
    { url: ownerAward.url, caption: "Receiving a player-of-the-match honour" },
    { url: ownerMedal.url, caption: "Sharing the podium with young talent at RCG" },
  ],
};

export function buildWhatsAppMessage(message: string) {
  return `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export type PricingCard = {
  label: string;
  time: string;
  price: string;
  includes?: string[];
  highlight?: boolean;
  badge?: string;
};

export const weekdayPricing: PricingCard[] = [
  {
    label: "Whole Day Package",
    time: "9:00 AM – 6:00 PM",
    price: "₹6,000",
    badge: "Best Value",
    highlight: true,
    includes: [
      "Live Streaming on YouTube",
      "CricHeroes Support",
      "2 Premium Leather Balls",
      "Medals",
      "Free WiFi",
    ],
  },
  { label: "Morning Slot", time: "6:45 AM – 10:15 AM", price: "₹3,000" },
  { label: "Midday Slot", time: "10:45 AM – 2:15 PM", price: "₹2,500" },
  { label: "Evening Slot", time: "2:30 PM – 6:00 PM", price: "₹2,500" },
];

export const weekendPricing: PricingCard[] = [
  {
    label: "Morning Slot",
    time: "6:45 AM – 10:15 AM",
    price: "₹9,000",
    includes: ["Medals", "Free WiFi"],
  },
  {
    label: "Midday Slot",
    time: "10:45 AM – 2:15 PM",
    price: "₹7,000",
    includes: ["Medals", "Free WiFi"],
  },
  {
    label: "Evening Slot",
    time: "2:30 PM – 6:00 PM",
    price: "₹7,000",
    includes: ["Medals", "Free WiFi"],
  },
];

export const defaultBookingMessage = buildWhatsAppMessage(
  "Hi Royal Cricket Ground, I want to book a cricket slot.",
);

export const icons = {
  phone: Phone,
  map: MapPinned,
  price: CircleDollarSign,
  store: Store,
};